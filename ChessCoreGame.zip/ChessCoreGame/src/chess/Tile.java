package chess;

public class Tile {
    Piece item;

    /** Constructor to make an empty Tile
     *  .item remains null
     */
    public Tile(){}

    /**
     * Constructor to make tiles with a piece
     * @param piece
     */
    public Tile(Piece piece){
        // Constructor for Tile with a Piece
        this.item = piece;
    }

    /** @return  true if tile.item is null. false if it contains a piece*/
    public boolean isEmpty(){
        return item == null;
    }


}
