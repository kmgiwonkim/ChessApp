package chess;

/**
 *  This package was coded such that the number of players
 */

enum playerColor {
    White,
    Black
}